package com.example.frontend.data.remote

data class VerifyDonationRequest(
    val status: String // isinya akan "success" atau "failed"
)