package com.example.frontend.ui.Donatur.History

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.frontend.data.remote.DonationHistoryItem
import com.example.frontend.data.repositories.HistoryRepository
import kotlinx.coroutines.launch

class DonationHistoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = HistoryRepository(application)
    private val _history = MutableLiveData<List<DonationHistoryItem>>()
    val history: LiveData<List<DonationHistoryItem>> = _history

    init {
        fetchHistory()
    }

    private fun fetchHistory() {
        viewModelScope.launch {
            try {
                val response = repository.getDonationHistory()
                if (response.isSuccessful) _history.postValue(response.body())
            } catch (e: Exception) { /* Handle error */ }
        }
    }
}