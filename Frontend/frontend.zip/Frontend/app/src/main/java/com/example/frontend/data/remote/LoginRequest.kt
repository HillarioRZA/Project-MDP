package com.example.frontend.data.remote

data class LoginRequest(
    val email: String,
    val password: String
)