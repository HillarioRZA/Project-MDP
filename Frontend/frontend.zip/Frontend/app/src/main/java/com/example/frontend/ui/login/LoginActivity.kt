package com.example.frontend.ui.login

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.StyleSpan
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.frontend.Manager.SessionManager
import com.example.frontend.ui.Home.HomeActivity
import com.example.frontend.ui.register.RegisterActivity
import com.example.frontend.databinding.ActivityLoginBinding
import com.example.frontend.ui.Admin.AdminActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class LoginActivity : AppCompatActivity() {
    private val viewModel: LoginViewModel by viewModels()
    private lateinit var binding: ActivityLoginBinding
    private lateinit var sessionManager: SessionManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        sessionManager = SessionManager(this)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.lifecycleOwner = this
        binding.viewModel = viewModel

        setupClickableRegisterLink()
        observeLoginResult()
    }
    private fun observeLoginResult() {
        viewModel.loginResult.observe(this) { result ->
            result.onSuccess { response ->
                val users = response.user
                val userName = response.user.firstName
                Toast.makeText(this, "Selamat datang kembali, $userName!", Toast.LENGTH_LONG).show()

                sessionManager.saveAuthToken(response.token)
                sessionManager.saveUserData(
                    name = "${response.user.firstName} ${response.user.lastName}",
                    email = response.user.email,
                    role = response.user.role
                )
                val savedToken = sessionManager.fetchAuthToken()
                sessionManager.saveUserId(users.user_id)


                // Pindah ke HomeActivity
                if (users.role == "admin") {
                    // Jika user adalah admin, arahkan ke AdminDashboardActivity
                    val intent = Intent(this, AdminActivity::class.java)
                    startActivity(intent)
                } else {
                    // Jika bukan admin (donatur/fundraiser), arahkan ke HomeActivity
                    val intent = Intent(this, HomeActivity::class.java)
                    startActivity(intent)
                }
                finish()
            }
            result.onFailure { error ->
                // Jika login gagal, tampilkan dialog error
                showErrorDialog(error.message ?: "Terjadi error tidak diketahui")
            }
        }
    }

    private fun showErrorDialog(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Login Gagal")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
    private fun setupClickableRegisterLink() {
        val fullText = "Belum punya akun? Daftar di sini"
        val spannableString = SpannableString(fullText)

        val clickableSpan = object : ClickableSpan() {
            override fun onClick(widget: View) {
                val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
                startActivity(intent)
            }
        }

        val startIndex = fullText.indexOf("Daftar di sini")
        val endIndex = startIndex + "Daftar di sini".length

        spannableString.setSpan(
            clickableSpan,
            startIndex,
            endIndex,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        spannableString.setSpan(
            StyleSpan(Typeface.BOLD),
            startIndex,
            endIndex,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        binding.tvGoToRegister.text = spannableString

        binding.tvGoToRegister.movementMethod = LinkMovementMethod.getInstance()
    }
}