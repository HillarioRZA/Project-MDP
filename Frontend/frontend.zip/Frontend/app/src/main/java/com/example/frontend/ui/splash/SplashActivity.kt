package com.example.frontend.ui.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.frontend.Manager.SessionManager
import com.example.frontend.R
import com.example.frontend.ui.Admin.AdminActivity
import com.example.frontend.ui.Home.HomeActivity
import com.example.frontend.ui.login.LoginActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_splash)
        Handler(Looper.getMainLooper()).postDelayed({
            val sessionManager = SessionManager(this)

            // Periksa apakah ada token yang tersimpan
            if (sessionManager.fetchAuthToken() != null) {
                // Jika ada token, langsung ke Halaman Home
                if (sessionManager.fetchRole() == "admin") {
                    val intent = Intent(this, AdminActivity::class.java)
                    startActivity(intent)
                }
                else{
                    val intent = Intent(this, HomeActivity::class.java)
                    startActivity(intent)
                }
            } else {
                // Jika tidak ada token, ke Halaman Login
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
            }

            // Tutup SplashActivity agar tidak bisa kembali dengan tombol back
            finish()
        }, 2000) // 2000 milidetik = 2 detik
    }
}