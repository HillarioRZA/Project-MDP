package com.example.frontend.data.remote

import com.squareup.moshi.Json

data class DisbursementCampaignInfo(
    @Json(name = "title")
    val title: String
)


data class DisbursementItem(
    @Json(name = "disbursement_id") // Sesuaikan dengan model Sequelize Anda
    val disbursementId: String,
    @Json(name = "campaign_id")
    val campaignId: String,
    @Json(name = "amount")
    val amount: Int,
    @Json(name = "status")
    val status: String,
    @Json(name = "request_at")
    val requestedAt: String,
    @Json(name = "Campaign")
    val campaign: DisbursementCampaignInfo
)

// Data class untuk body request saat verifikasi
data class VerifyDisbursementRequest(
    val status: String // isinya 'approved' atau 'rejected'
)

// Data class untuk respons setelah verifikasi
data class VerifyDisbursementResponse(
    val message: String,
    val disbursement: DisbursementItem
)