package com.example.frontend.ui.fundraiser.createCampaign

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.frontend.data.remote.CampaignItem
import com.example.frontend.data.repositories.CampaignRepository
import kotlinx.coroutines.launch

class CreateCampaignViewModel(application: Application) : AndroidViewModel(application) {

    private val campaignRepository = CampaignRepository(application)

    // LiveData untuk menampung input dari form
    val title = MutableLiveData<String>()
    val description = MutableLiveData<String>()
    val targetAmount = MutableLiveData<String>()

    // LiveData untuk hasil proses
    private val _creationResult = MutableLiveData<Result<CampaignItem>>()
    val creationResult: LiveData<Result<CampaignItem>> = _creationResult

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun submitCampaign(
        title: String,
        description: String,
        targetAmount: String,
        imageUri: Uri?,
    ) {
        // Validasi sekarang menggunakan parameter, bukan LiveData.value
        if (title.isBlank() || description.isBlank() || targetAmount.isBlank()) {
            _creationResult.value = Result.failure(Exception("Semua field teks wajib diisi"))
            return
        }
        if (imageUri == null) {
            _creationResult.value = Result.failure(Exception("Gambar sampul wajib diupload"))
            return
        }

        _isLoading.value = true
        viewModelScope.launch {
            try {
                // Panggil repository dengan parameter yang sudah bersih
                val response = campaignRepository.createCampaign(title, description, targetAmount, imageUri)
                if (response.isSuccessful && response.body() != null) {
                    _creationResult.postValue(Result.success(response.body()!!))
                } else {
                    _creationResult.postValue(Result.failure(Exception("Gagal membuat kampanye: ${response.errorBody()?.string()}")))
                }
            } catch (e: Exception) {
                _creationResult.postValue(Result.failure(e))
            } finally {
                _isLoading.postValue(false)
            }
        }
    }
}