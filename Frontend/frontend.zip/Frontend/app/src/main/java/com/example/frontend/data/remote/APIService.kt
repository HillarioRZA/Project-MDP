package com.example.frontend.data.remote
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.PartMap
import retrofit2.http.Path

interface APIService {
    @POST("login")
    suspend fun login(
        @Body loginRequest: LoginRequest
    ): Response<LoginResponse>

    @POST("register")
    suspend fun register(
        @Body registerRequest: RegisterRequest
    ): Response<RegisterResponse>

    @GET("campaigns") // Endpoint untuk mendapatkan semua campaign
    suspend fun getCampaigns(): Response<List<CampaignItem>>

    @GET("campaigns/{id}") // Endpoint untuk mendapatkan detail by ID
    suspend fun getCampaignById(
        @Path("id") campaignId: String // Mengambil ID dari URL
    ): Response<CampaignItem>

    @GET("campaigns/{id}/donations")
    suspend fun getDonationsByCampaignId(
        @Path("id") campaignId: String
    ): Response<List<DonatorItem>>

    @Multipart
    @POST("donations")
    suspend fun createDonation(
        @PartMap data: Map<String, @JvmSuppressWildcards RequestBody>,
        @Part file: MultipartBody.Part
    ): Response<DonationResponse>

    @GET("admin/dashboard/stats")
    suspend fun getDashboardStats(): Response<DashboardStatsResponse>

    @GET("admin/donations/pending")
    suspend fun getPendingDonations(): Response<List<PendingDonationItem>>

    @PATCH("admin/donations/{donationId}/verify")
    suspend fun verifyDonation(
        @Path("donationId") donationId: String,
        @Body request: VerifyDonationRequest
    ): Response<DonationResponse>

    @GET("disbursements")
    suspend fun getPendingDisbursements(): Response<List<DisbursementItem>>

    @PATCH("disbursements/{id}/verify")
    suspend fun verifyDisbursement(
        @Path("id") disbursementId: String,
        @Body request: VerifyDisbursementRequest
    ): Response<VerifyDisbursementResponse>


    // Admin memverifikasi status campaign
    @PATCH("campaigns/{id}/status")
    suspend fun verifyCampaign(
        @Path("id") campaignId: String,
        @Body request: VerifyRequest
    ): Response<ResponseBody>

    @Multipart
    @POST("campaigns")
    suspend fun createCampaign(
        @PartMap data: Map<String, @JvmSuppressWildcards RequestBody>,
        // Pastikan key "campaign-images" cocok dengan setup multer Anda
        @Part file: MultipartBody.Part
    ): Response<CampaignItem>

    @POST("campaigns/{id}/disbursements")
    suspend fun requestDisbursement(
        @Path("id") campaignId: String,
        @Body request: RequestDisbursementRequest
    ): Response<DisbursementItem>

    @GET("users/me/donations")
    suspend fun getDonationHistory(): Response<List<DonationHistoryItem>>
}