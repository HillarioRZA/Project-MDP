package com.example.frontend.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.frontend.data.local.UserDao
import com.example.frontend.data.local.UserEntity

// Deklarasikan semua entity yang ada di database ini
@Database(entities = [UserEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    // Deklarasikan semua DAO yang ada di database ini
    abstract fun userDao(): UserDao

    companion object {
        // @Volatile memastikan instance ini selalu up-to-date dan aman untuk multi-threading
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            // Jika instance sudah ada, langsung kembalikan.
            // Jika belum ada, buat instance baru di dalam blok synchronized.
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "together_we_give_database" // Nama file database
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}