package com.example.frontend.ui.Admin

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.frontend.data.remote.PendingDonationItem
import com.example.frontend.databinding.ItemAdminVerifyDonationBinding
import java.text.NumberFormat
import java.util.Locale

class AdminDonationVerifyAdapter(
    private var items: List<PendingDonationItem>,
    // Fungsi callback untuk meneruskan aksi klik ke Activity/ViewModel
    private val onApproveClick: (PendingDonationItem) -> Unit,
    private val onRejectClick: (PendingDonationItem) -> Unit,
    private val onProofClick: (String) -> Unit // Mengirim URL bukti
) : RecyclerView.Adapter<AdminDonationVerifyAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemAdminVerifyDonationBinding) : RecyclerView.ViewHolder(binding.root)

    fun updateData(newItems: List<PendingDonationItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAdminVerifyDonationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvDonatorInfo.text = "${item.donatorName} berdonasi ke '${item.campaignTitle}'"

        val localeID = Locale("in", "ID")
        val currencyFormat = NumberFormat.getCurrencyInstance(localeID).apply { maximumFractionDigits = 0 }
        holder.binding.tvDonationAmount.text = currencyFormat.format(item.amount)

        // Atur OnClickListener untuk setiap tombol
        holder.binding.btnApprove.setOnClickListener { onApproveClick(item) }
        holder.binding.btnReject.setOnClickListener { onRejectClick(item) }
        holder.binding.btnViewProof.setOnClickListener { onProofClick(item.proofOfPaymentUrl) }
    }
}