package com.example.frontend.data.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.frontend.data.local.UserEntity

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateUser(user: UserEntity)

    @Query("SELECT * FROM user WHERE user_id = :userId")
    fun getUserById(userId: String): LiveData<UserEntity>

    @Query("DELETE FROM user")
    suspend fun clearUser()
}