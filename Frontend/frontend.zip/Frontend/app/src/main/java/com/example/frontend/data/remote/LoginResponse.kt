package com.example.frontend.data.remote

data class UserData(
    val user_id: String,
    val firstName: String,
    val lastName: String,
    val email: String,
    val role: String
)

data class LoginResponse(
    val user: UserData,
    val token: String
)