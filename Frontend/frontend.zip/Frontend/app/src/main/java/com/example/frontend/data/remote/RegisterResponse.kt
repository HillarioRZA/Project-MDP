package com.example.frontend.data.remote

import com.squareup.moshi.Json

// Class ini mencerminkan objek 'user' yang dikembalikan backend
data class RegisterResponse(
    @Json(name = "user_id") // Cocokkan dengan field JSON dari backend
    val userId: String,

    val firstName: String,
    val lastName: String,
    val email: String,
    val role: String,
    val createdAt: String, // Kita terima sebagai String dulu untuk kemudahan
    val updatedAt: String
)