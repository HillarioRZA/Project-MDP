package com.example.frontend.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

// @Entity menandakan class ini adalah sebuah tabel database
@Entity(tableName = "user")
data class UserEntity(
    // @PrimaryKey menandakan ini adalah kunci utama tabel
    @PrimaryKey
    @ColumnInfo(name = "user_id") // Nama kolom di database
    val userId: String,

    @ColumnInfo(name = "first_name")
    val firstName: String,

    @ColumnInfo(name = "last_name")
    val lastName: String,

    @ColumnInfo(name = "email")
    val email: String,

    @ColumnInfo(name = "role")
    val role: String
)