package com.example.frontend.data.repositories

import android.content.Context
import android.net.Uri
import com.example.frontend.data.remote.RetrofitInstance
import com.example.frontend.data.remote.CampaignItem
import com.example.frontend.data.remote.DonatorItem
import com.example.frontend.data.remote.RequestDisbursementRequest
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import java.io.File

class CampaignRepository(private val context: Context) {
    private val apiService = RetrofitInstance.create(context)

    suspend fun getCampaigns(): Response<List<CampaignItem>> {
        return apiService.getCampaigns()
    }
    suspend fun getCampaignById(campaignId: String): Response<CampaignItem> {
        return apiService.getCampaignById(campaignId)
    }
    suspend fun getDonationsByCampaignId(campaignId: String): Response<List<DonatorItem>> {
        return apiService.getDonationsByCampaignId(campaignId)
    }
    suspend fun createCampaign(
        title: String,
        description: String,
        targetAmount: String,
        imageUri: Uri
    ): Response<CampaignItem> {
        // Siapkan file gambar untuk di-upload
        val imagePart = createMultipartBody(imageUri, "campaign_images") // Gunakan key dari Anda

        // Siapkan data teks
        val dataMap = mutableMapOf<String, RequestBody>()
        val textMediaType = MediaType.get("text/plain")
        dataMap["title"] = RequestBody.create(textMediaType, title)
        dataMap["description"] = RequestBody.create(textMediaType, description)
        dataMap["targetAmount"] = RequestBody.create(textMediaType, targetAmount)

        return apiService.createCampaign(dataMap, imagePart)
    }
    private fun createMultipartBody(uri: Uri, partName: String): MultipartBody.Part {
        val inputStream = context.contentResolver.openInputStream(uri)
        val file = File(context.cacheDir, "temp_image_${System.currentTimeMillis()}")
        inputStream.use { input ->
            file.outputStream().use { output ->
                input?.copyTo(output)
            }
        }
        val mediaType = "image/*".let { MediaType.get(it) }
        val requestFile = RequestBody.create(mediaType, file)
        return MultipartBody.Part.createFormData(partName, file.name, requestFile)
    }
    suspend fun requestDisbursement(campaignId: String, amount: Int) =
        apiService.requestDisbursement(
            campaignId = campaignId,
            request = RequestDisbursementRequest(amount = amount)
        )
    suspend fun getDisbursementHistory() = apiService.getPendingDisbursements()
}