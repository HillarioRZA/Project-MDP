package com.example.frontend.ui.fundraiser.Disbursement

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.frontend.databinding.ActivityRequestDisbursementBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.NumberFormat
import java.util.Locale

class RequestDisbursementActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRequestDisbursementBinding
    private val viewModel: RequestDisbursementViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRequestDisbursementBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val campaignId = intent.getStringExtra("CAMPAIGN_ID")
        val campaignTitle = intent.getStringExtra("CAMPAIGN_TITLE")
        val availableAmount = intent.getIntExtra("AVAILABLE_AMOUNT", 0)

        // Tampilkan data awal
        binding.tvCampaignTitleForDisbursement.text = "Pencairan Dana untuk '$campaignTitle'"
        val localeID = Locale("in", "ID")
        val currencyFormat = NumberFormat.getCurrencyInstance(localeID).apply { maximumFractionDigits = 0 }
        binding.tvAvailableFundsForDisbursement.text = currencyFormat.format(availableAmount)

        // Setup tombol
        binding.btnSubmitDisbursement.setOnClickListener {
            val amount = binding.etDisbursementAmount.text.toString()
            viewModel.submitRequest(campaignId!!, amount, availableAmount)
        }

        // Observasi hasil
        viewModel.result.observe(this) { result ->
            result.onSuccess {
                showSuccessDialog()
            }.onFailure {
                Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showSuccessDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Pengajuan Berhasil")
            .setMessage("Permintaan pencairan dana Anda telah diajukan dan akan diverifikasi oleh admin.")
            .setPositiveButton("OK") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }
}