package com.example.frontend.ui.Donatur.DonatePage

import android.content.Intent
import android.view.View
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.frontend.Manager.SessionManager
import com.example.frontend.R
import com.example.frontend.databinding.ActivityDonateBinding
import com.example.frontend.databinding.ActivityLoginBinding
import com.example.frontend.ui.Home.HomeActivity
import java.util.Locale
import java.text.NumberFormat
import android.net.Uri
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels

class DonateActivity : AppCompatActivity() {
    private val viewModel: DonationViewModel by viewModels()
    private lateinit var binding: ActivityDonateBinding
    private lateinit var sessionManager: SessionManager
    private lateinit var imagePickerLauncher: ActivityResultLauncher<String>
    private var selectedImageUri: Uri? = null
    private var campaignId: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        sessionManager = SessionManager(this)
        binding = ActivityDonateBinding.inflate(layoutInflater)
        setContentView(binding.root)
        campaignId = intent.getStringExtra("CAMPAIGN_ID")

        if (campaignId == null) {
            Toast.makeText(this, "ID Kampanye tidak valid", Toast.LENGTH_SHORT).show()
            finish()
            return // Hentikan eksekusi jika ID tidak ada
        }

        imagePickerLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                // Saat gambar berhasil dipilih, simpan URI-nya dan tampilkan di ImageView
                selectedImageUri = it
                binding.ivProofPreview.setImageURI(it)
            }
        }
        observeViewModel()
        setupToolbar()
        setupInitialData()
        setupButtonListeners()

        // Tampilkan seksi pertama saat activity pertama kali dibuat
        showSection(1)
    }
    private fun observeViewModel() {
        viewModel.donationResult.observe(this) { result ->
            result.onSuccess { response ->
                // Jika sukses, tampilkan seksi 3
                binding.tvThankYouMessage.text = response.message
                showSection(3)
            }
            result.onFailure { error ->
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
    private fun submitDonation() {
        val amount = binding.etAmount.text.toString()
        val isAnonymous = binding.checkboxAnonymous.isChecked

        viewModel.submitDonation(campaignId!!, amount, isAnonymous, selectedImageUri)
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    private fun setupInitialData() {
        // Ambil dan tampilkan nama pengguna yang login
        binding.tvUserNameReadonly.text = sessionManager.fetchName() ?: "Donatur"
    }

    private fun setupButtonListeners() {
        // Tombol di SEKSI 1
        binding.btnNextToUpload.setOnClickListener {
            // TODO: Tambahkan validasi nominal donasi di sini
            updateDonationSummary()
            showSection(2) // Pindah ke seksi 2
        }

        // Tombol di SEKSI 2
        binding.btnBackToInput.setOnClickListener {
            showSection(1) // Kembali ke seksi 1
        }
        binding.btnSelectImage.setOnClickListener {
            imagePickerLauncher.launch("image/*")
        }
        binding.btnConfirmDonation.setOnClickListener {
            submitDonation()
            showSection(3) // Pindah ke seksi 3 (sukses)
        }

        // Tombol di SEKSI 3
        binding.btnGoToHome.setOnClickListener {
            // Kembali ke halaman Home
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }
    }
    // Fungsi untuk memperbarui ringkasan donasi di seksi 2
    private fun updateDonationSummary() {
        val amount = binding.etAmount.text.toString().toDoubleOrNull() ?: 0.0
        val isAnonymous = binding.checkboxAnonymous.isChecked

        val localeID = Locale("in", "ID")
        val currencyFormat = NumberFormat.getCurrencyInstance(localeID).apply { maximumFractionDigits = 0 }
        val amountFormatted = currencyFormat.format(amount)

        val summaryText = "Ringkasan: Donasi $amountFormatted (${if (isAnonymous) "Anonim" else "Publik"})"
        binding.tvDonationSummary.text = summaryText

        // TODO: Simpan juga nama campaign untuk ditampilkan di halaman sukses
        // binding.section3Success.tvThankYouMessage.text = "Terima kasih telah..."
    }

    // Fungsi inti untuk mengontrol visibilitas setiap seksi
    private fun showSection(sectionNumber: Int) {
        // Sembunyikan semua seksi terlebih dahulu
        binding.section1Input.visibility = View.GONE
        binding.section2Upload.visibility = View.GONE
        binding.section3Success.visibility = View.GONE

        // Tampilkan seksi yang dipilih
        when (sectionNumber) {
            1 -> binding.section1Input.visibility = View.VISIBLE
            2 -> binding.section2Upload.visibility = View.VISIBLE
            3 -> binding.section3Success.visibility = View.VISIBLE
        }
    }

    // Fungsi agar tombol back di toolbar berfungsi
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}