package com.example.frontend.data.remote

import com.squareup.moshi.Json

data class CampaignCreator(
    @Json(name = "user_id")
    val userId: String,

    @Json(name = "firstName")
    val firstName: String,

    @Json(name = "lastName")
    val lastName: String
)
// Data class ini harus cocok dengan field yang dikembalikan oleh Sequelize model Anda
data class CampaignItem(
    @Json(name = "campaign_id") // Sesuaikan dengan nama field di backend jika berbeda
    val id: String,

    @Json(name = "User") // Nama "User" harus sama persis dengan yang dikirim backend
    val creator: CampaignCreator,

    @Json(name = "title")
    val title: String,

    @Json(name = "description")
    val description: String,

    @Json(name = "target_amount")
    val goalAmount: Int,

    @Json(name = "current_amount")
    val currentAmount: Int,

    @Json(name = "image_url")
    val imageUrl: String,

    @Json(name = "status")
    val status: String,
    @Json(name = "Disbursements") // Sesuaikan dengan nama dari backend
    val disbursements: List<DisbursementItem>?
)
