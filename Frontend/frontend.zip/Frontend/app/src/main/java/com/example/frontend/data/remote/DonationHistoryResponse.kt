package com.example.frontend.data.remote
import com.squareup.moshi.Json

// DTO untuk satu item riwayat donasi
data class DonationHistoryItem(
    @Json(name = "donation_id")
    val donationId: String,
    @Json(name = "amount")
    val amount: Int,
    @Json(name = "status")
    val status: String,
    @Json(name = "createdAt")
    val createdAt: String,
    // Objek nested dari hasil 'include' Campaign
    @Json(name = "Campaign")
    val campaign: CampaignInfo? // Dibuat nullable untuk keamanan
)

// DTO untuk info campaign yang di-include
data class CampaignInfo(
    @Json(name = "title")
    val title: String
)