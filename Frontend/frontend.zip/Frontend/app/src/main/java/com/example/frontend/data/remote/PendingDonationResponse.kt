package com.example.frontend.data.remote

import com.squareup.moshi.Json

data class PendingDonationItem(
    @Json(name = "donation_id")
    val donationId: String,

    @Json(name = "nama_donatur")
    val donatorName: String,

    @Json(name = "campaign_title")
    val campaignTitle: String,

    @Json(name = "jumlah")
    val amount: Int,

    @Json(name = "bukti_transaksi")
    val proofOfPaymentUrl: String,

    @Json(name = "waktu_donasi")
    val donationTime: String
)