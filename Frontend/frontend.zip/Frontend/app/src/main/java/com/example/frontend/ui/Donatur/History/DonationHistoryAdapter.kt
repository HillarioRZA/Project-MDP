package com.example.frontend.ui.Donatur.History

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.frontend.R
import com.example.frontend.data.remote.DonationHistoryItem
import com.example.frontend.databinding.ItemDonationHistoryBinding
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class DonationHistoryAdapter(
    private var items: List<DonationHistoryItem> = emptyList()
) : RecyclerView.Adapter<DonationHistoryAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemDonationHistoryBinding) : RecyclerView.ViewHolder(binding.root)

    fun updateData(newItems: List<DonationHistoryItem>) {
        this.items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemDonationHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context

        // 1. Menampilkan Judul Kampanye
        holder.binding.tvCampaignTitleHistory.text = "Donasi untuk '${item.campaign?.title ?: "Kampanye Telah Dihapus"}'"

        // 2. Memformat dan Menampilkan Jumlah Donasi
        val localeID = Locale("in", "ID")
        val currencyFormat = NumberFormat.getCurrencyInstance(localeID).apply { maximumFractionDigits = 0 }
        holder.binding.tvAmountHistory.text = currencyFormat.format(item.amount)

        // 3. Memformat dan Menampilkan Tanggal
        holder.binding.tvDateHistory.text = "Pada: ${formatDate(item.createdAt)}"

        // 4. Mengatur Teks dan Warna Status Chip
        when (item.status.lowercase()) {
            "success" -> {
                holder.binding.chipStatusHistory.text = "Berhasil"
                holder.binding.chipStatusHistory.setChipBackgroundColorResource(R.color.brand_green)
            }
            "pending" -> {
                holder.binding.chipStatusHistory.text = "Pending"
                holder.binding.chipStatusHistory.setChipBackgroundColorResource(R.color.status_pending)
            }
            "failed" -> {
                holder.binding.chipStatusHistory.text = "Gagal"
                holder.binding.chipStatusHistory.setChipBackgroundColorResource(R.color.brand_red)
            }
            else -> {
                holder.binding.chipStatusHistory.text = item.status.capitalize()
                holder.binding.chipStatusHistory.setChipBackgroundColorResource(android.R.color.darker_gray)
            }
        }
    }

    private fun formatDate(isoString: String): String {
        return try {
            val serverFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val date = serverFormat.parse(isoString)

            val displayFormat = SimpleDateFormat("dd MMM yyyy", Locale("in", "ID"))
            displayFormat.format(date!!)
        } catch (e: Exception) {
            "Tanggal tidak valid"
        }
    }
}