package com.example.frontend.data.model

data class Category(
    val name: String
)