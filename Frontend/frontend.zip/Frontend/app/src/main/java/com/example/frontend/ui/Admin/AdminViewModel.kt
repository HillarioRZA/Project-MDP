package com.example.frontend.ui.Admin

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.frontend.data.model.StatItem
import com.example.frontend.data.remote.CampaignItem
import com.example.frontend.data.remote.DisbursementItem
import com.example.frontend.data.remote.PendingDonationItem
import com.example.frontend.data.repositories.AdminRepository
import kotlinx.coroutines.launch

class AdminViewModel(application: Application) : AndroidViewModel(application) {

    private val adminRepository = AdminRepository(application)

    // LiveData untuk menampung daftar item statistik untuk RecyclerView
    private val _statsList = MutableLiveData<List<StatItem>>()
    val statsList: LiveData<List<StatItem>> = _statsList

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    private val _pendingDonations = MutableLiveData<List<PendingDonationItem>>()
    val pendingDonations: LiveData<List<PendingDonationItem>> = _pendingDonations

    private val _verificationResult = MutableLiveData<Event<String>>()
    val verificationResult: LiveData<Event<String>> = _verificationResult

    private val _pendingDisbursements = MutableLiveData<List<DisbursementItem>>()
    val pendingDisbursements: LiveData<List<DisbursementItem>> = _pendingDisbursements

    private val _pendingCampaigns = MutableLiveData<List<CampaignItem>>()
    val pendingCampaigns: LiveData<List<CampaignItem>> = _pendingCampaigns

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    init {
        fetchDashboardStats()
        fetchPendingDonations()
        fetchPendingDisbursements()
        fetchCampaignsForVerification()
    }

     fun fetchDashboardStats() {
        viewModelScope.launch {
            try {
                val response = adminRepository.getDashboardStats()
                if (response.isSuccessful && response.body() != null) {
                    val statsData = response.body()!!.data
                    // Ubah data dari API menjadi list yang bisa dibaca oleh Adapter
                    val formattedStats = listOf(
                        StatItem(statsData.totalFundraisers.toString(), "Fundraiser"),
                        StatItem(statsData.activeCampaigns.toString(), "Campaign Aktif"),
                        StatItem(statsData.completedCampaigns.toString(), "Campaign Selesai")
                    )
                    _statsList.postValue(formattedStats)
                } else {
                    _error.postValue("Gagal mengambil statistik")
                }
            } catch (e: Exception) {
                _error.postValue("Error: ${e.message}")
            }
        }
    }
    fun fetchPendingDonations() {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val response = adminRepository.getPendingDonations()
                if (response.isSuccessful && response.body() != null) {
                    _pendingDonations.postValue(response.body())
                } else {
                    _error.postValue("Gagal memuat donasi pending")
                }
            } catch (e: Exception) {
                _error.postValue(e.message)
            } finally {
                _isLoading.postValue(false) // <-- Atur loading = false setelah selesai
            }
        }
    }

    fun approveDonation(donationId: String) {
        verifyDonation(donationId, true)
    }

    fun rejectDonation(donationId: String) {
        verifyDonation(donationId, false)
    }

    private fun verifyDonation(donationId: String, isSuccess: Boolean) {
        viewModelScope.launch {
            try {
                val response = adminRepository.verifyDonation(donationId, isSuccess)
                if (response.isSuccessful && response.body() != null) {
                    _verificationResult.postValue(Event(response.body()!!.message))
                    fetchPendingDonations() // Ambil ulang daftar terbaru setelah verifikasi
                } else {
                    _error.postValue("Verifikasi gagal: ${response.errorBody()?.string()}")
                }
            } catch (e: Exception) {
                _error.postValue(e.message)
            }
        }
    }
    fun fetchPendingDisbursements() {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val response = adminRepository.getPendingDisbursements()
                if (response.isSuccessful && response.body() != null) {
                    // Filter di sisi klien untuk menampilkan yang 'pending' saja
                    val pendingList = response.body()!!.filter { it.status == "pending" }
                    _pendingDisbursements.postValue(pendingList)
                } else {
                    _error.postValue("Gagal memuat disbursement pending")
                }
            } catch (e: Exception) {
                _error.postValue(e.message)
            }finally {
                _isLoading.postValue(false) // <-- Atur loading = false setelah selesai
            }
        }
    }

    fun approveDisbursement(disbursementId: String) {
        verifyDisbursement(disbursementId, "approved")
    }

    fun rejectDisbursement(disbursementId: String) {
        verifyDisbursement(disbursementId, "rejected")
    }

    private fun verifyDisbursement(disbursementId: String, status: String) {
        viewModelScope.launch {
            try {
                val response = adminRepository.verifyDisbursement(disbursementId, status)
                if (response.isSuccessful && response.body() != null) {
                    _verificationResult.postValue(Event(response.body()!!.message))
                    fetchPendingDisbursements() // Ambil ulang daftar terbaru
                } else {
                    _error.postValue("Verifikasi disbursement gagal")
                }
            } catch (e: Exception) {
                _error.postValue(e.message)
            }
        }
    }
    fun fetchCampaignsForVerification() {
        viewModelScope.launch {
            _isLoading.postValue(true)
            try {
                val response = adminRepository.getAllCampaigns()
                if (response.isSuccessful) {
                    // Filter untuk menampilkan yang 'pending' saja
                    val pendingList = response.body()?.filter { it.status == "pending" }
                    _pendingCampaigns.postValue(pendingList!!)
                } else {
                    _error.postValue("Gagal memuat kampanye pending")
                }
            } catch (e: Exception) {
                _error.postValue(e.message)
            } finally {
                _isLoading.postValue(false)
            }
        }
    }

    fun approveCampaign(campaignId: String) {
        updateCampaignStatus(campaignId, "active")
    }

    fun rejectCampaign(campaignId: String) {
        updateCampaignStatus(campaignId, "rejected")
    }

    private fun updateCampaignStatus(campaignId: String, status: String) {
        viewModelScope.launch {
            try {
                val response = adminRepository.verifyCampaign(campaignId, status)
                if (response.isSuccessful) {
                    _verificationResult.postValue(Event("Status kampanye berhasil diupdate"))
                    fetchCampaignsForVerification() // Refresh daftar
                } else {
                    _error.postValue("Gagal update status kampanye")
                }
            } catch (e: Exception) {
                _error.postValue(e.message)
            }
        }
    }
}

// Buat class Event ini di file terpisah (misal: util/Event.kt) untuk menangani event sekali jalan
open class Event<out T>(private val content: T) {
    private var hasBeenHandled = false
    fun getContentIfNotHandled(): T? {
        return if (hasBeenHandled) {
            null
        } else {
            hasBeenHandled = true
            content
        }
    }

}