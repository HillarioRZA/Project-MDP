package com.example.frontend.ui.Home

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.frontend.Manager.SessionManager
import com.example.frontend.R
import com.example.frontend.ui.Home.adapter.CampaignAdapter
import com.example.frontend.ui.Home.adapter.CategoryAdapter
import com.example.frontend.data.model.Category
import com.example.frontend.databinding.ActivityHomeBinding
import com.example.frontend.ui.DetailCampaign.DetailCampaignActivity
import com.example.frontend.ui.Donatur.History.DonationHistoryActivity
import com.example.frontend.ui.fundraiser.DisbursementHistoryActivity
import com.example.frontend.ui.fundraiser.createCampaign.CreateCampaignActivity
import com.example.frontend.ui.login.LoginActivity

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private val viewModel: HomeViewModel by viewModels()
    private lateinit var sessionManager: SessionManager
    private lateinit var campaignAdapter: CampaignAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityHomeBinding.inflate(layoutInflater)
        sessionManager = SessionManager(this)
        setContentView(binding.root)
        setSupportActionBar(binding.topAppBar)
        setupRecyclerViews()
        observeViewModel()
        setupDummyData()
        setupWelcomeCard()
        setupSwipeToRefresh()
        if(sessionManager.fetchRole() == "donatur"){
            binding.fabCreateCampaign.visibility = View.GONE
            binding.tvCategoryTitle.text = "Jelajahi Kategori"
            binding.rvCategories.visibility = View.VISIBLE
        }else{
            binding.fabCreateCampaign.visibility = View.VISIBLE
            binding.tvCategoryTitle.text = "List Campaign Saya"
            binding.rvCategories.visibility = View.GONE
            binding.fabCreateCampaign.setOnClickListener {
                val intent = Intent(this, CreateCampaignActivity::class.java)
                startActivity(intent)
            }
        }
    }
    private fun setupSwipeToRefresh() {
        binding.swipeRefreshLayoutHome.setOnRefreshListener {
            // Saat ditarik, panggil fungsi untuk mengambil data lagi
            viewModel.fetchCampaigns()
        }
    }
    private fun setupRecyclerViews() {
        campaignAdapter = CampaignAdapter(emptyList(), sessionManager.fetchRole()){ selectedCampaign ->
            // Kode di dalam sini akan dieksekusi saat sebuah kartu diklik

            // Buat Intent untuk pindah ke DetailCampaignActivity
            val intent = Intent(this, DetailCampaignActivity::class.java)

            // Selipkan ID kampanye yang dipilih ke dalam Intent
            intent.putExtra("CAMPAIGN_ID", selectedCampaign.id)

            // Jalankan Intent
            startActivity(intent)
        }
        binding.rvCampaigns.adapter = campaignAdapter
    }
    private fun observeViewModel() {
        viewModel.campaigns.observe(this) { campaignList ->
            campaignAdapter.updateData(campaignList)
        }

        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        viewModel.error.observe(this) { errorMessage ->
            if (errorMessage.isNotEmpty()) {
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
            }
        }
        viewModel.isLoading.observe(this) { isLoading ->
            // isRefreshing akan menampilkan/menyembunyikan ikon loading putar
            binding.swipeRefreshLayoutHome.isRefreshing = isLoading
        }
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.home_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_search -> {
                Toast.makeText(this, "Tombol Cari diklik", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_notifications -> {
                Toast.makeText(this, "Tombol Notifikasi diklik", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_logout -> {
                // Panggil fungsi logout dari SessionManager
                sessionManager.logout() // Pastikan sessionManager sudah diinisialisasi

                // Buat Intent untuk kembali ke LoginActivity
                val intent = Intent(this, LoginActivity::class.java)
                // Flag ini akan menghapus semua activity sebelumnya dari back stack
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish() // Tutup HomeActivity
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    private fun setupWelcomeCard() {
        val userName = sessionManager.fetchName()
        val userRole = sessionManager.fetchRole()
        if (userName != null) {
            binding.userWelcomeCard.tvUserName.text = userName
        } else {
            binding.userWelcomeCard.tvUserName.text = "Pengguna"
        }

        binding.userWelcomeCard.btnHistory.setOnClickListener {
            if (userRole == "fundraiser") {
                // JIKA FUNDRAISER, buka DisbursementHistoryActivity
                val intent = Intent(this, DisbursementHistoryActivity::class.java)
                startActivity(intent)
            } else {
                val intent = Intent(this, DonationHistoryActivity::class.java)
                startActivity(intent)
            }
        }
    }
    private fun setupDummyData() {
        // Data dummy untuk kategori
        val categoryList = listOf(
            Category("Semua"),
            Category("Pendidikan"),
            Category("Kesehatan"),
            Category("Bencana Alam"),
            Category("Lingkungan"),
            Category("Anak Yatim")
        )
        val categoryAdapter = CategoryAdapter(categoryList)
        binding.rvCategories.adapter = categoryAdapter
    }
}