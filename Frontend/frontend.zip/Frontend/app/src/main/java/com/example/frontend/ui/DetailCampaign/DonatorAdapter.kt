package com.example.frontend.ui.DetailCampaign

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.frontend.R
import com.example.frontend.data.remote.DonatorItem
import com.example.frontend.databinding.ItemDonatorBinding
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import android.util.Log

class DonatorAdapter(private var items: List<DonatorItem> = emptyList()) : RecyclerView.Adapter<DonatorAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemDonatorBinding) : RecyclerView.ViewHolder(binding.root)

    fun updateData(newItems: List<DonatorItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemDonatorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val donator = items[position]
        Log.d("DonationAdapterCheck", "Binding item di posisi $position: ${donator.donatorName}")

        try {
            if (donator.donatorName.equals("Anonim", ignoreCase = true)) {
                holder.binding.tvDonatorName.text = "Donatur Anonim"
                holder.binding.ivDonatorAvatar.setImageResource(R.drawable.ic_person)
            } else {
                holder.binding.tvDonatorName.text = donator.donatorName
            }
            Log.d("DonationAdapterCheck", "Nama berhasil di-set: ${holder.binding.tvDonatorName.text}")

            val localeID = Locale("in", "ID")
            val currencyFormat = NumberFormat.getCurrencyInstance(localeID).apply { maximumFractionDigits = 0 }
            holder.binding.tvDonationAmount.text = currencyFormat.format(donator.amount)
            Log.d("DonationAdapterCheck", "Jumlah berhasil di-set: ${holder.binding.tvDonationAmount.text}")

            // Format waktu (misal: "2 jam yang lalu")
            holder.binding.tvDonationTime.text = "• " + formatRelativeTime(donator.donationTime)
            Log.d("DonationAdapterCheck", "Waktu berhasil di-set: ${holder.binding.tvDonationTime.text}")

        } catch (e: Exception) {
            Log.e("DonationAdapterCheck", "ERROR saat binding di posisi $position: ${e.message}")
        }
    }

    // Fungsi helper untuk mengubah format waktu
    private fun formatRelativeTime(isoString: String): String {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            val time = sdf.parse(isoString)?.time ?: return ""
            val now = System.currentTimeMillis()
            val diff = now - time

            val seconds = diff / 1000
            val minutes = seconds / 60
            val hours = minutes / 60
            val days = hours / 24

            when {
                days > 0 -> "$days hari yang lalu"
                hours > 0 -> "$hours jam yang lalu"
                minutes > 0 -> "$minutes menit yang lalu"
                else -> "baru saja"
            }
        } catch (e: Exception) {
            Log.e("DonationAdapterCheck", "Gagal mem-format waktu: $isoString, Error: ${e.message}")
            "beberapa waktu lalu"
        }
    }
}