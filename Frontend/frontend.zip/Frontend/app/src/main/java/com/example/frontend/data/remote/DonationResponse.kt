package com.example.frontend.data.remote

data class DonationData(
    val donation_id: String,
    val user_id: String,
    val campaign_id: String,
    val amount: Int,
    val is_anonymous: Boolean,
    val status: String,
    val bukti_transaksi: String
)

// Class untuk menampung seluruh objek respons
data class DonationResponse(
    val message: String,
    val donation: DonationData
)