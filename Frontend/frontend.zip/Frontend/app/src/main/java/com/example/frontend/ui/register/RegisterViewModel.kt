package com.example.frontend.ui.register

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.frontend.data.remote.RegisterResponse
import com.example.frontend.data.repositories.AuthRepository
import kotlinx.coroutines.launch
import android.app.Application
import androidx.lifecycle.AndroidViewModel

class RegisterViewModel(application: Application) : AndroidViewModel(application) {

    private val authRepository = AuthRepository(application)

    val firstName = MutableLiveData<String>()
    val lastName = MutableLiveData<String>()
    val email = MutableLiveData<String>()
    val password = MutableLiveData<String>()
    val role = MutableLiveData<String>()

    private val _registrationResult = MutableLiveData<Result<RegisterResponse>>()
    val registrationResult: LiveData<Result<RegisterResponse>> = _registrationResult

    fun onRoleSelected(selectedRole: String) {
        role.value = selectedRole
    }

    fun onRegisterClicked() {
        val fName = firstName.value ?: ""
        val lName = lastName.value ?: ""
        val mail = email.value ?: ""
        val pass = password.value ?: ""
        val selectedRole = role.value ?: ""

        if (fName.isBlank() || lName.isBlank() || mail.isBlank() || pass.isBlank() || selectedRole.isBlank()) {
            _registrationResult.value = Result.failure(Exception("Semua field harus diisi"))
            return
        }

        viewModelScope.launch {
            try {
                val response = authRepository.register(fName, lName, mail, pass, selectedRole)
                if (response.isSuccessful && response.body() != null) {
                    _registrationResult.postValue(Result.success(response.body()!!))
                } else {
                    val errorMessage = response.errorBody()?.string() ?: "Registrasi gagal"
                    _registrationResult.postValue(Result.failure(Exception(errorMessage)))
                }
            } catch (e: Exception) {
                _registrationResult.postValue(Result.failure(Exception("Terjadi error: ${e.message}")))
            }
        }
    }
}