package com.example.frontend.data.remote

import com.squareup.moshi.Json

data class DashboardStats(
    @Json(name = "totalFundraisers")
    val totalFundraisers: Int,

    @Json(name = "activeCampaigns")
    val activeCampaigns: Int,

    @Json(name = "completedCampaigns")
    val completedCampaigns: Int
)

// Class ini untuk menampung seluruh objek respons
data class DashboardStatsResponse(
    @Json(name = "success")
    val success: Boolean,

    @Json(name = "data")
    val data: DashboardStats
)