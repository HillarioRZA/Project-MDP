package com.example.frontend.ui.DetailCampaign

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.frontend.Manager.SessionManager
import com.example.frontend.R
import com.example.frontend.data.remote.RetrofitInstance
import com.example.frontend.databinding.ActivityDetailCampaignBinding
import com.example.frontend.ui.Donatur.DonatePage.DonateActivity
import com.example.frontend.ui.fundraiser.Disbursement.RequestDisbursementActivity
import com.google.android.material.tabs.TabLayout
import java.text.NumberFormat
import java.util.Locale

class DetailCampaignActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailCampaignBinding
    private val viewModel: DetailCampaignViewModel by viewModels()
    private lateinit var donatorAdapter: DonatorAdapter
    private lateinit var sessionManager: SessionManager
    private var campaignId: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityDetailCampaignBinding.inflate(layoutInflater)
        sessionManager = SessionManager(this)
        setContentView(binding.root)
        binding.contentDonatur.layoutManager = LinearLayoutManager(this)
        setupToolbar()

        campaignId = intent.getStringExtra("CAMPAIGN_ID")

        if (campaignId != null) {
            // 2. Jika ID valid, perintahkan ViewModel untuk mengambil data
            viewModel.fetchCampaignData(campaignId!!)
        } else {
            // Jika ID tidak valid, tampilkan error dan tutup halaman
            Toast.makeText(this, "ID Kampanye tidak valid", Toast.LENGTH_SHORT).show()
            finish()
        }

        // 3. Amati data dari ViewModel
        setupRecyclerViews()
        observeViewModel()
        setupTabLayout()
        setupDonateButton()
        setupSwipeToRefresh()
    }
    private fun setupSwipeToRefresh() {
        binding.swipeRefreshDetail.setOnRefreshListener {
            // Jika ID campaign tidak null, panggil ulang fetch data
            campaignId?.let {
                viewModel.fetchCampaignData(it)
            }
        }
    }
    private fun setupDonateButton() {
        binding.btnDonateNow.setOnClickListener {
            // Buat Intent untuk pindah ke DonateActivity
            val intent = Intent(this, DonateActivity::class.java)
            // Selipkan ID kampanye yang sedang aktif
            intent.putExtra("CAMPAIGN_ID", campaignId)
            startActivity(intent)
        }
    }
    private fun setupRecyclerViews() {
        donatorAdapter = DonatorAdapter()
        binding.contentDonatur.adapter = donatorAdapter
        binding.contentDonatur.layoutManager = LinearLayoutManager(this) // Jangan lupa LayoutManager
    }
    private fun observeViewModel() {
        viewModel.campaignDetail.observe(this) { campaign ->
            // Saat data detail datang, panggil fungsi untuk mengisi UI
            populateUi(campaign)
        }


        viewModel.error.observe(this) { error ->
            if (error.isNotEmpty()) {
                Toast.makeText(this, error, Toast.LENGTH_LONG).show()
            }
        }
        viewModel.donators.observe(this) { donatorList ->
            donatorAdapter.updateData(donatorList)
        }
        viewModel.isLoading.observe(this) { isLoading ->
            // isRefreshing akan menampilkan/menyembunyikan ikon loading putar
            binding.swipeRefreshDetail.isRefreshing = isLoading
        }
    }

    // Fungsi baru yang rapi untuk mengisi semua data ke UI
    private fun populateUi(campaign: com.example.frontend.data.remote.CampaignItem) {
        val localeID = Locale("in", "ID")
        val numberFormat = NumberFormat.getCurrencyInstance(localeID).apply {
            maximumFractionDigits = 0
        }

        // Menampilkan data ke semua komponen UI
        binding.toolbar.title = campaign.title
        binding.tvCampaignDetailTitle.text = campaign.title
        binding.tvCreatorName.text = "Digalang oleh: ${campaign.creator.firstName} ${campaign.creator.lastName}"
        binding.contentCerita.text = campaign.description

        binding.tvTarget.text = "Target: ${numberFormat.format(campaign.goalAmount)}"
        binding.tvCollected.text = "Terkumpul: ${numberFormat.format(campaign.currentAmount)}"

        val progress = (campaign.currentAmount.toDouble() / campaign.goalAmount.toDouble() * 100).toInt()
        binding.progressBar.progress = progress
        val fullImageUrl = RetrofitInstance.BASE_URL + "uploads/campaign-images/"+campaign.imageUrl.substring(24)
        Glide.with(this)
            .load(fullImageUrl)
            .into(binding.ivCampaignDetailImage)
        setupDynamicButton(campaign)
    }
    private fun setupDynamicButton(campaign: com.example.frontend.data.remote.CampaignItem) {
        val currentUserRole = sessionManager.fetchRole()
        // Cek apakah yang login adalah fundraiser dan pemilik kampanye ini
        if (currentUserRole == "fundraiser") {
            // Logika untuk FUNDRAISER
            when (campaign.status) {
                "completed" -> {
                    if (campaign.disbursements.isNullOrEmpty()) {
                        // JIKA BELUM, tampilkan tombol
                        binding.btnDonateNow.visibility = View.VISIBLE
                        binding.btnDonateNow.text = "Ajukan Pencairan Dana"
                        binding.btnDonateNow.setOnClickListener {
                            val intent = Intent(this, RequestDisbursementActivity::class.java)
                            intent.putExtra("CAMPAIGN_ID", campaign.id)
                            intent.putExtra("CAMPAIGN_TITLE", campaign.title)
                            intent.putExtra("AVAILABLE_AMOUNT", campaign.currentAmount)
                            startActivity(intent)
                        }
                    } else {
                        // JIKA SUDAH, sembunyikan tombol
                        binding.btnDonateNow.visibility = View.GONE
                    }
                }
                else -> {
                    // Untuk status lain (pending, active, rejected), sembunyikan tombol
                    binding.btnDonateNow.visibility = View.GONE
                }
            }
        } else {
            // Logika untuk DONATUR (atau user lain)
            if (campaign.status == "active") {
                binding.btnDonateNow.visibility = View.VISIBLE
                binding.btnDonateNow.text = "Donasi Sekarang"
                binding.btnDonateNow.setOnClickListener {
                    // Intent ke halaman Donasi
                    val intent = Intent(this, com.example.frontend.ui.Donatur.DonatePage.DonateActivity::class.java)
                    intent.putExtra("CAMPAIGN_ID", campaign.id)
                    startActivity(intent)
                }
            } else {
                // Jika campaign tidak aktif, sembunyikan tombol donasi
                binding.btnDonateNow.visibility = View.GONE
            }
        }
    }
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = ""
    }

    private fun setupTabLayout() {
        // Atur agar tab pertama terpilih secara default
        showTabContent(0)

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                tab?.let { showTabContent(it.position) }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
        // Tampilkan konten tab pertama secara default
        showTabContent(0)
    }
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
    private fun showTabContent(position: Int) {
        // Sembunyikan semua konten terlebih dahulu
        binding.contentCerita.visibility = View.GONE
        binding.contentDonatur.visibility = View.GONE
        // TODO: sembunyikan konten "Update" jika ada

        // Tampilkan konten yang sesuai dengan posisi tab
        when (position) {
            0 -> binding.contentCerita.visibility = View.VISIBLE
            //1 -> { /* TODO: Tampilkan konten "Update" */ }
            1-> binding.contentDonatur.visibility = View.VISIBLE
        }
    }
}