package com.example.frontend.data.remote

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import android.content.Context

object RetrofitInstance {
    const val BASE_URL = "http://192.168.1.6:3000/api/v1/"
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    fun getOkHttpClient(context: Context): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor(context))
            .build()
    }
    fun create(context: Context): APIService {
        // 2. Buat Retrofit dan PASTIKAN untuk menggunakan client yang sudah kita buat
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(getOkHttpClient(context))// <-- INI BAGIAN KUNCINYA
            .addConverterFactory(MoshiConverterFactory.create(moshi).asLenient())
            .build()

        // 3. Kembalikan service yang sudah siap pakai
        return retrofit.create(APIService::class.java)
    }

}