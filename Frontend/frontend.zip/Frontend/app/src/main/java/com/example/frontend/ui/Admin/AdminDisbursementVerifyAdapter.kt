package com.example.frontend.ui.Admin

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.frontend.data.remote.DisbursementItem
import com.example.frontend.databinding.ItemAdminVerifyDisbursementBinding
import java.text.NumberFormat
import java.util.Locale

class AdminDisbursementVerifyAdapter(
    private var items: List<DisbursementItem>,
    private val onApproveClick: (DisbursementItem) -> Unit,
    private val onRejectClick: (DisbursementItem) -> Unit
) : RecyclerView.Adapter<AdminDisbursementVerifyAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemAdminVerifyDisbursementBinding) : RecyclerView.ViewHolder(binding.root)

    fun updateData(newItems: List<DisbursementItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAdminVerifyDisbursementBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        // TODO: Tampilkan data campaign title dan fundraiser name jika ada di DTO Anda
        holder.binding.tvCampaignTitleDisbursement.text = "Pencairan untuk Campaign ID: ${item.campaignId}"

        val localeID = Locale("in", "ID")
        val currencyFormat = NumberFormat.getCurrencyInstance(localeID).apply { maximumFractionDigits = 0 }
        holder.binding.tvAmountDisbursement.text = currencyFormat.format(item.amount)

        holder.binding.btnApproveDisbursement.setOnClickListener { onApproveClick(item) }
        holder.binding.btnRejectDisbursement.setOnClickListener { onRejectClick(item) }
    }
}