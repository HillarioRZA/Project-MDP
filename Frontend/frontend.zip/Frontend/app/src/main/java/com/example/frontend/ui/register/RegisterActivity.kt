package com.example.frontend.ui.register

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.frontend.ui.login.LoginActivity
import com.example.frontend.databinding.ActivityRegisterBinding
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.StyleSpan
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class RegisterActivity : AppCompatActivity() {
    private val viewModel: RegisterViewModel by viewModels()
    private lateinit var binding: ActivityRegisterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.lifecycleOwner = this
        binding.viewModel = viewModel
        setupClickableLoginLink()
        observeRegistrationResult()

    }
    private fun observeRegistrationResult() {
        viewModel.registrationResult.observe(this) { result ->
            result.onSuccess { response ->
                // Jika registrasi sukses
                Toast.makeText(this, "Registrasi Berhasil! Silakan Login.", Toast.LENGTH_LONG).show()
                // Pindah ke halaman login
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish() // Tutup halaman ini agar tidak bisa kembali
            }
            result.onFailure { error ->
                // Jika registrasi gagal
                showErrorDialog(error.message ?: "Terjadi error tidak diketahui")
            }
        }
    }
    private fun showErrorDialog(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Registrasi Gagal") // Judul dialog
            .setMessage(message) // Pesan error dari ViewModel
            .setPositiveButton("Coba Lagi") { dialog, _ ->
                dialog.dismiss() // Tutup dialog saat tombol ditekan
            }
            .show() // Tampilkan dialog
    }
    private fun setupClickableLoginLink() {
        val fullText = "Sudah punya akun? Masuk"
        val spannableString = SpannableString(fullText)

        val clickableSpan = object : ClickableSpan() {
            override fun onClick(widget: View) {
                val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
                startActivity(intent)
            }
        }

        val startIndex = fullText.indexOf("Masuk")
        val endIndex = startIndex + "Masuk".length

        spannableString.setSpan(
            clickableSpan,
            startIndex,
            endIndex,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        spannableString.setSpan(
            StyleSpan(Typeface.BOLD),
            startIndex,
            endIndex,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        binding.tvGoToLogin.text = spannableString

        binding.tvGoToLogin.movementMethod = LinkMovementMethod.getInstance()
    }
}