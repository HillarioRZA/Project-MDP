package com.example.frontend.ui.Admin

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.frontend.Manager.SessionManager
import com.example.frontend.R
import com.example.frontend.data.model.StatItem
import com.example.frontend.data.remote.RetrofitInstance
import com.example.frontend.databinding.ActivityAdminBinding
import com.example.frontend.databinding.ActivityDetailCampaignBinding
import com.example.frontend.ui.DetailCampaign.DetailCampaignActivity
import com.example.frontend.ui.login.LoginActivity
import com.google.android.material.tabs.TabLayout
import com.bumptech.glide.load.engine.GlideException // <-- Import baru
import com.bumptech.glide.request.RequestListener // <-- Import baru
import com.bumptech.glide.request.target.Target // <-- Import baru
import android.graphics.drawable.Drawable
import com.bumptech.glide.load.DataSource


class AdminActivity : AppCompatActivity() {
    private lateinit var statsAdapter: AdminStatsAdapter
    private lateinit var binding: ActivityAdminBinding
    private lateinit var sessionManager: SessionManager
    private lateinit var donationVerifyAdapter: AdminDonationVerifyAdapter
    private lateinit var disbursementVerifyAdapter: AdminDisbursementVerifyAdapter
    private lateinit var campaignVerifyAdapter: AdminCampaignVerifyAdapter
    private val viewModel: AdminViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityAdminBinding.inflate(layoutInflater)
        sessionManager = SessionManager(this)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        setupStatsRecyclerView()
        observeViewModel()
        setupTabLayout()
        setupVerificationRecyclerViews()
        setupSwipeToRefresh()
    }
    private fun setupSwipeToRefresh() {
        binding.swipeRefreshLayout.setOnRefreshListener {
            viewModel.fetchPendingDonations()
            viewModel.fetchPendingDisbursements()
            viewModel.fetchCampaignsForVerification()
            viewModel.fetchDashboardStats()
        }
    }
    private fun setupStatsRecyclerView() {
        statsAdapter = AdminStatsAdapter(emptyList())
        binding.rvStats.adapter = statsAdapter
        binding.rvStats.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
    }
    private fun setupVerificationRecyclerViews() {
        // Setup adapter untuk verifikasi donasi
        donationVerifyAdapter = AdminDonationVerifyAdapter(
            emptyList(),
            onApproveClick = { donation -> viewModel.approveDonation(donation.donationId) },
            onRejectClick = { donation -> viewModel.rejectDonation(donation.donationId) },
            onProofClick = { imageUrl -> showProofDialog(imageUrl) }
        )
        binding.rvDonations.adapter = donationVerifyAdapter
        binding.rvDonations.layoutManager = LinearLayoutManager(this)

        disbursementVerifyAdapter = AdminDisbursementVerifyAdapter(
            emptyList(),
            onApproveClick = { disbursement -> viewModel.approveDisbursement(disbursement.disbursementId) },
            onRejectClick = { disbursement -> viewModel.rejectDisbursement(disbursement.disbursementId) }
        )
        binding.rvDisbursements.adapter = disbursementVerifyAdapter
        binding.rvDisbursements.layoutManager = LinearLayoutManager(this)

        campaignVerifyAdapter = AdminCampaignVerifyAdapter(
            emptyList(),
            onApproveClick = { campaign -> viewModel.approveCampaign(campaign.id) },
            onRejectClick = { campaign -> viewModel.rejectCampaign(campaign.id) },
            onViewDetailClick = { campaign ->
                val intent = Intent(this, DetailCampaignActivity::class.java)
                intent.putExtra("CAMPAIGN_ID", campaign.id)
                startActivity(intent)
            }
        )
        binding.rvCampaignsVerify.adapter = campaignVerifyAdapter
        binding.rvCampaignsVerify.layoutManager = LinearLayoutManager(this)
    }

    // Fungsi baru untuk mengamati data dari ViewModel
    private fun observeViewModel() {
        viewModel.statsList.observe(this) { stats ->
            // Saat data statistik datang, perbarui adapter
            statsAdapter.updateData(stats) // Kita perlu fungsi updateData di adapter
        }

        viewModel.error.observe(this) { errorMessage ->
            if (errorMessage.isNotEmpty()) {
                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
            }
        }

        viewModel.pendingDonations.observe(this) { donations ->
            donationVerifyAdapter.updateData(donations)
        }

        // Tambahkan observer untuk hasil verifikasi
        viewModel.verificationResult.observe(this) { event ->
            event.getContentIfNotHandled()?.let { message ->
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }
        }
        viewModel.pendingDisbursements.observe(this) { disbursements ->
            disbursementVerifyAdapter.updateData(disbursements)
        }
        viewModel.isLoading.observe(this) { isLoading ->
            binding.swipeRefreshLayout.isRefreshing = isLoading
        }
        viewModel.pendingCampaigns.observe(this) { campaigns ->
            campaignVerifyAdapter.updateData(campaigns)
        }
    }
    private fun showProofDialog(imageUrl: String) {
        if (isFinishing) return

        val builder = AlertDialog.Builder(this)
        val inflater = layoutInflater
        // Gunakan layout kustom untuk dialog agar lebih terkontrol
        val dialogView = inflater.inflate(R.layout.dialog_image_viewer, null)

        val imageView = dialogView.findViewById<ImageView>(R.id.iv_dialog_image)
        val progressBar = dialogView.findViewById<ProgressBar>(R.id.pb_dialog_image)

        // Tampilkan ProgressBar saat gambar sedang dimuat
        progressBar.visibility = View.VISIBLE

        val fullImageUrl = RetrofitInstance.BASE_URL + "uploads/bukti-transaksi/"+imageUrl.substring(24)
        Log.d("fullImageURL", fullImageUrl)
        Glide.with(this)
            .load(fullImageUrl)
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>,
                    isFirstResource: Boolean
                ): Boolean {
                    progressBar.visibility = View.GONE
                    // Jika gagal, kita bisa set gambar error
                    imageView.setImageResource(R.drawable.ic_logo)
                    Log.e("AdminProofCheck", "Glide gagal memuat gambar: ${e?.message}")
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable,
                    model: Any,
                    target: Target<Drawable>?,
                    dataSource: DataSource,
                    isFirstResource: Boolean
                ): Boolean {
                    progressBar.visibility = View.GONE
                    // Jika berhasil, biarkan Glide yang menampilkannya
                    return false
                }
            })
            .into(imageView)

        builder.setView(dialogView)
        builder.setPositiveButton("Tutup") { dialog, _ ->
            dialog.dismiss()
        }
        builder.create().show()
    }
    private fun setupTabLayout() {
        // Tampilkan konten tab pertama (Disbursement) saat pertama kali dibuka
        showTabContent(0)

        binding.tabLayoutAdmin.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                tab?.let {
                    showTabContent(it.position)
                    // Jika tab yang relevan dipilih, refresh datanya
                    when (it.position) {
                        0 -> viewModel.fetchPendingDisbursements()
                        1 -> viewModel.fetchCampaignsForVerification()
                        2 -> viewModel.fetchPendingDonations()
                    }
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }
    private fun showTabContent(position: Int) {
        binding.rvDisbursements.visibility = View.GONE
        binding.rvCampaignsVerify.visibility = View.GONE // <-- Sembunyikan juga yg baru
        binding.rvDonations.visibility = View.GONE

        // Tampilkan RecyclerView yang sesuai dengan posisi tab yang dipilih
        when (position) {
            0 -> binding.rvDisbursements.visibility = View.VISIBLE // Tab "Disbursement"
            1 -> binding.rvCampaignsVerify.visibility = View.VISIBLE  // Tab "Campaign"
            2 -> binding.rvDonations.visibility = View.VISIBLE   // Tab "Donasi"
        }
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.admin_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_logout_admin -> {
                sessionManager.logout()
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}