package com.example.frontend.ui.fundraiser

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.frontend.data.remote.DisbursementItem
import com.example.frontend.data.repositories.CampaignRepository
import kotlinx.coroutines.launch

class DisbursementHistoryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = CampaignRepository(application)

    private val _historyList = MutableLiveData<List<DisbursementItem>>()
    val historyList: LiveData<List<DisbursementItem>> = _historyList

    init {
        fetchHistory()
    }

    fun fetchHistory() {
        viewModelScope.launch {
            try {
                val response = repository.getDisbursementHistory()
                if (response.isSuccessful) {
                    _historyList.postValue(response.body())
                }
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
}