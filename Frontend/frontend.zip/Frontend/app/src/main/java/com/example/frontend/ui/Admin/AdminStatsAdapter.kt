package com.example.frontend.ui.Admin

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.frontend.data.model.StatItem
import com.example.frontend.databinding.ItemAdminStatCardBinding

class AdminStatsAdapter(private var items: List<StatItem>) : RecyclerView.Adapter<AdminStatsAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemAdminStatCardBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAdminStatCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val stat = items[position]
        holder.binding.tvStatValue.text = stat.value
        holder.binding.tvStatLabel.text = stat.label
    }
    fun updateData(newStats: List<StatItem>) {
        this.items = newStats
        notifyDataSetChanged()
    }
}