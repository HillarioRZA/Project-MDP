package com.example.frontend.ui.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.frontend.data.remote.LoginResponse
import com.example.frontend.data.repositories.AuthRepository
import kotlinx.coroutines.launch
import android.app.Application
import androidx.lifecycle.AndroidViewModel

class LoginViewModel(application: Application) : AndroidViewModel(application) {

    private val authRepository = AuthRepository(application)

    // LiveData untuk input email dan password dari XML
    val email = MutableLiveData<String>()
    val password = MutableLiveData<String>()

    // LiveData untuk memberi tahu Activity tentang hasil login
    private val _loginResult = MutableLiveData<Result<LoginResponse>>()
    val loginResult: LiveData<Result<LoginResponse>> = _loginResult

    fun onLoginClicked() {
        val currentEmail = email.value ?: ""
        val currentPassword = password.value ?: ""

        if (currentEmail.isBlank() || currentPassword.isBlank()) {
            _loginResult.value = Result.failure(Exception("Email dan password tidak boleh kosong"))
            return
        }

        viewModelScope.launch {
            try {
                val response = authRepository.login(currentEmail, currentPassword)
                if (response.isSuccessful && response.body() != null) {
                    _loginResult.postValue(Result.success(response.body()!!))
                } else {
                    val errorMessage = response.errorBody()?.string() ?: "Login gagal"
                    _loginResult.postValue(Result.failure(Exception(errorMessage)))
                }
            } catch (e: Exception) {
                _loginResult.postValue(Result.failure(Exception("Terjadi error: ${e.message}")))
            }
        }
    }
}