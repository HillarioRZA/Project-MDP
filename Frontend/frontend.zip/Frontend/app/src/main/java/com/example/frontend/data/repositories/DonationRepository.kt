package com.example.frontend.data.repositories

import android.content.Context
import android.net.Uri
import com.example.frontend.data.remote.RetrofitInstance
import com.example.frontend.data.remote.DonationResponse // <-- PASTIKAN IMPORT INI BENAR
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import java.io.File

class DonationRepository(private val context: Context) {
    // Panggil fungsi create dari RetrofitInstance dengan context
    private val apiService = RetrofitInstance.create(context)

    suspend fun createDonation(
        campaignId: String,
        amount: String,
        isAnonymous: Boolean,
        imageUri: Uri
    ): Response<DonationResponse> {
        val filePart = createMultipartBody(imageUri, "bukti_transaksi")

        val dataMap = mutableMapOf<String, RequestBody>()
        val textMediaType = MediaType.get("text/plain")

        dataMap["campaignId"] = RequestBody.create(textMediaType, campaignId)
        dataMap["amount"] = RequestBody.create(textMediaType, amount)
        dataMap["isAnonymous"] = RequestBody.create(textMediaType, isAnonymous.toString())

        return apiService.createDonation(dataMap, filePart)
    }

    // Fungsi helper untuk mengubah URI menjadi MultipartBody.Part
    private fun createMultipartBody(uri: Uri, partName: String): MultipartBody.Part {
        val inputStream = context.contentResolver.openInputStream(uri)
        val file = File(context.cacheDir, "temp_image_${System.currentTimeMillis()}")
        inputStream.use { input ->
            file.outputStream().use { output ->
                input?.copyTo(output)
            }
        }
        val mediaType = "image/*".let { MediaType.get(it) }
        val requestFile = RequestBody.create(mediaType, file)
        return MultipartBody.Part.createFormData(partName, file.name, requestFile)
    }
}