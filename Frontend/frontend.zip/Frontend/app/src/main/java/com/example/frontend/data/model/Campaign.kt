package com.example.frontend.data.model

import androidx.annotation.DrawableRes

data class Campaign(
    val imageUrl: String,
    val title: String,
    val fundraiserName: String,
    val amountCollected: String,
    val targetAmount: String,
    val progress: Int // Angka 0-100 untuk ProgressBar
)