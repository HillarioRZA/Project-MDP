package com.example.frontend.ui.fundraiser.Disbursement

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.frontend.data.remote.DisbursementItem
import com.example.frontend.data.repositories.CampaignRepository
import kotlinx.coroutines.launch

class RequestDisbursementViewModel(application: Application) : AndroidViewModel(application) {
    private val campaignRepository = CampaignRepository(application)

    private val _result = MutableLiveData<Result<DisbursementItem>>()
    val result: LiveData<Result<DisbursementItem>> = _result

    fun submitRequest(campaignId: String, amountStr: String, maxAmount: Int) {
        val amount = amountStr.toIntOrNull()
        if (amount == null || amount <= 0) {
            _result.value = Result.failure(Exception("Jumlah tidak valid"))
            return
        }
        if (amount > maxAmount) {
            _result.value = Result.failure(Exception("Jumlah melebihi dana yang tersedia"))
            return
        }

        viewModelScope.launch {
            try {
                val response = campaignRepository.requestDisbursement(campaignId, amount)
                if (response.isSuccessful) {
                    _result.postValue(Result.success(response.body()!!))
                } else {
                    _result.postValue(Result.failure(Exception("Gagal mengajukan: ${response.errorBody()?.string()}")))
                }
            } catch (e: Exception) {
                _result.postValue(Result.failure(e))
            }
        }
    }
}