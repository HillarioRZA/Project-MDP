package com.example.frontend.data.remote

data class RequestDisbursementRequest(
    val amount: Int
)