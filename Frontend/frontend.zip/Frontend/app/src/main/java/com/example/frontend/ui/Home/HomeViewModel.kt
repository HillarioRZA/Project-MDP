package com.example.frontend.ui.Home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.frontend.data.remote.CampaignItem
import com.example.frontend.data.repositories.CampaignRepository
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val campaignRepository = CampaignRepository(application)

    private val _campaigns = MutableLiveData<List<CampaignItem>>()

    val campaigns: LiveData<List<CampaignItem>> = _campaigns


    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading


    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    init {
        fetchCampaigns()
    }

    fun fetchCampaigns() {
        _isLoading.value = true

        viewModelScope.launch {
            try {
                val response = campaignRepository.getCampaigns()
                if (response.isSuccessful && response.body() != null) {
                    _campaigns.postValue(response.body())
                } else {
                    _error.postValue("Gagal memuat data: ${response.message()}")
                }
            } catch (e: Exception) {
                _error.postValue("Terjadi error: ${e.message}")
            } finally {
                _isLoading.postValue(false)
            }
        }
    }
}