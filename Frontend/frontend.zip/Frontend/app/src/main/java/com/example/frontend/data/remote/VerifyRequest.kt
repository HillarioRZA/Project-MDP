package com.example.frontend.data.remote

import com.squareup.moshi.Json

data class VerifyRequest(
    @Json(name = "status")
    val status: String // Contoh isinya: "active", "rejected", "success", dll.
)