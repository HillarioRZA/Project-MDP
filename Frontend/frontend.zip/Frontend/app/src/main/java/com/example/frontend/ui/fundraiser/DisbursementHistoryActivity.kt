package com.example.frontend.ui.fundraiser

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.frontend.databinding.ActivityDisbursementHistoryBinding

class DisbursementHistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDisbursementHistoryBinding
    private val viewModel: DisbursementHistoryViewModel by viewModels()
    private lateinit var adapter: DisbursementHistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDisbursementHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        observeViewModel()
    }
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        // Perintah untuk menampilkan panah kembali
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    private fun setupRecyclerView(){
        adapter = DisbursementHistoryAdapter(emptyList())
        binding.rvDisbursementHistory.adapter = adapter
        binding.rvDisbursementHistory.layoutManager = LinearLayoutManager(this)
    }

    private fun observeViewModel(){
        viewModel.historyList.observe(this){ history ->
            adapter.updateData(history)
        }
    }
}