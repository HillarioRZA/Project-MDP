package com.example.frontend.ui.Admin

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.frontend.data.remote.CampaignItem
import com.example.frontend.data.remote.RetrofitInstance
import com.example.frontend.databinding.ItemAdminVerifyCampaignBinding

class AdminCampaignVerifyAdapter(
    private var items: List<CampaignItem>,
    private val onApproveClick: (CampaignItem) -> Unit,
    private val onRejectClick: (CampaignItem) -> Unit,
    private val onViewDetailClick: (CampaignItem) -> Unit
) : RecyclerView.Adapter<AdminCampaignVerifyAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemAdminVerifyCampaignBinding) : RecyclerView.ViewHolder(binding.root)

    fun updateData(newItems: List<CampaignItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAdminVerifyCampaignBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvCampaignTitleVerify.text = item.title
        val creatorName = "${item.creator.firstName} ${item.creator.lastName}"
        holder.binding.tvFundraiserNameVerify.text = "oleh: $creatorName"
        val fullImageUrl = RetrofitInstance.BASE_URL + "uploads/campaign-images/"+item.imageUrl.substring(24)
        Glide.with(holder.itemView.context)
            .load(fullImageUrl)
            .into(holder.binding.ivCampaignImageVerify)

        holder.binding.btnApprove.setOnClickListener { onApproveClick(item) }
        holder.binding.btnReject.setOnClickListener { onRejectClick(item) }
        holder.binding.btnViewDetail.setOnClickListener { onViewDetailClick(item) }
    }
}