package com.example.frontend.data.repositories

import android.content.Context
import com.example.frontend.data.remote.RetrofitInstance

class HistoryRepository(private val context: Context) {
    private val apiService = RetrofitInstance.create(context)
    suspend fun getDonationHistory() = apiService.getDonationHistory()
}