package com.example.frontend.data.remote

import android.content.Context
import android.util.Log
import com.example.frontend.Manager.SessionManager
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(private val context: Context) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        // Ambil SessionManager untuk mendapatkan token
        val sessionManager = SessionManager(context)
        val token = sessionManager.fetchAuthToken()

        // Ambil request asli
        val originalRequest = chain.request()

        val baseUrl = RetrofitInstance.BASE_URL

        // Jika token ada, tambahkan header Authorization
        if (originalRequest.url().toString().startsWith(baseUrl) && token != null) {
            // JIKA YA, dan token ada, tambahkan header
            val newRequest = originalRequest.newBuilder()
                .header("Authorization", "Bearer $token")
                .build()
            Log.d("AuthInterceptor", "Token yang dikirim: $token")
            return chain.proceed(newRequest)
        }



        // Jika tidak ada token, lanjutkan dengan request asli
        return chain.proceed(originalRequest)
    }
}