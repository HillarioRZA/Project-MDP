package com.example.frontend.data.repositories

import android.content.Context
import com.example.frontend.data.local.AppDatabase
import com.example.frontend.data.local.UserDao
import com.example.frontend.data.local.UserEntity
import com.example.frontend.data.remote.LoginRequest
import com.example.frontend.data.remote.LoginResponse
import com.example.frontend.data.remote.RegisterRequest
import com.example.frontend.data.remote.RetrofitInstance
import retrofit2.Response

class AuthRepository(private val context: Context) {

    // Mengambil instance APIService dari RetrofitInstance
    private val apiService = RetrofitInstance.create(context)
    private val userDao: UserDao
    init {
        val database = AppDatabase.getInstance(context)
        userDao = database.userDao()
    }
    suspend fun register(
        firstName: String,
        lastName: String,
        email: String,
        password: String,
        role: String
    ) = apiService.register(
        RegisterRequest(
            firstName = firstName,
            lastName = lastName,
            email = email,
            password = password,
            role = role
        )
    )
    suspend fun login(email: String, password: String): Response<LoginResponse> {
        // Panggil API seperti biasa
        val response = apiService.login(LoginRequest(email, password))

        // 3. JIKA respons sukses, SIMPAN data user ke Room Database
        if (response.isSuccessful && response.body() != null) {
            val userData = response.body()!!.user
            val userEntity = UserEntity(
                userId = userData.user_id,
                firstName = userData.firstName,
                lastName = userData.lastName,
                email = userData.email,
                role = userData.role
            )
            // Panggil fungsi DAO untuk menyimpan
            userDao.insertOrUpdateUser(userEntity)
        }

        // Kembalikan respons asli ke ViewModel
        return response
    }
}