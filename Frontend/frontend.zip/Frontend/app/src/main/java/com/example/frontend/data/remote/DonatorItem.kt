package com.example.frontend.data.remote
import com.squareup.moshi.Json

data class DonatorItem(
    @Json(name = "nama_donatur")
    val donatorName: String,

    @Json(name = "jumlah")
    val amount: Int,

    @Json(name = "waktu_donasi")
    val donationTime: String
)