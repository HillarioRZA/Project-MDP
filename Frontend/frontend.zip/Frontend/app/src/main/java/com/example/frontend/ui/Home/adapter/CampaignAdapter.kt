package com.example.frontend.ui.Home.adapter

import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.frontend.R
import com.example.frontend.data.remote.CampaignItem
import com.example.frontend.data.remote.RetrofitInstance
import com.example.frontend.databinding.ItemCampaignCardBinding
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.log

class CampaignAdapter(private var items: List<CampaignItem> = emptyList(),private val userRole: String?,private val onItemClick: (CampaignItem) -> Unit) : RecyclerView.Adapter<CampaignAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemCampaignCardBinding) : RecyclerView.ViewHolder(binding.root)
    fun updateData(newItems: List<CampaignItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemCampaignCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val campaign = items[position]

        val fullImageUrl = RetrofitInstance.BASE_URL + "uploads/campaign-images/"+campaign.imageUrl.substring(24)
        Log.d("CampaignAdapter", "Image URL: $fullImageUrl")
        Glide.with(holder.itemView.context)
            .load(fullImageUrl)
            .into(holder.binding.ivCampaignImage)

        holder.binding.tvCampaignTitle.text = campaign.title
        if (userRole == "fundraiser") {
            // TAMPILAN UNTUK FUNDRAISER
            holder.binding.tvFundraiserName.text = "Status: ${campaign.status.uppercase()}"
            // Beri warna berbeda berdasarkan status
            when (campaign.status) {
                "active" -> holder.binding.tvFundraiserName.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.brand_green))
                "pending" -> holder.binding.tvFundraiserName.setTextColor(Color.BLUE)
                "rejected", "cancelled" -> holder.binding.tvFundraiserName.setTextColor(Color.RED)
                else -> holder.binding.tvFundraiserName.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.text_secondary))
            }
        } else {
            // TAMPILAN UNTUK DONATUR (default)
            val creatorName = "${campaign.creator.firstName} ${campaign.creator.lastName}"
            holder.binding.tvFundraiserName.text = "Digalang oleh: $creatorName"
            holder.binding.tvFundraiserName.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.text_secondary))
        }

        // Format angka menjadi format Rupiah
        val localeID = Locale("in", "ID")
        val numberFormat = NumberFormat.getCurrencyInstance(localeID)
        numberFormat.maximumFractionDigits = 0 // Hapus desimal

        holder.binding.tvAmountCollected.text = numberFormat.format(campaign.currentAmount.toDouble())
        holder.binding.tvTargetAmount.text = numberFormat.format(campaign.goalAmount.toDouble())

        // Hitung persentase progress
        val progress = (campaign.currentAmount.toDouble() / campaign.goalAmount.toDouble() * 100).toInt()
        holder.binding.pbCampaignProgress.progress = progress

        holder.itemView.setOnClickListener {
            onItemClick(campaign) // Panggil fungsi callback dengan data campaign yang diklik
        }
    }
}