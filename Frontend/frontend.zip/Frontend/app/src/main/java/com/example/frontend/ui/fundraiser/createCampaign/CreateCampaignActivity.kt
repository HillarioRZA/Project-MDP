package com.example.frontend.ui.fundraiser.createCampaign

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.frontend.databinding.ActivityCreateCampaignBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class CreateCampaignActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCreateCampaignBinding
    private val viewModel: CreateCampaignViewModel by viewModels()
    private lateinit var imagePickerLauncher: ActivityResultLauncher<String>
    private var selectedImageUri: Uri? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityCreateCampaignBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.lifecycleOwner = this
        setupToolbar()
        setupImagePicker()
        setupButtonListener()
        observeViewModel()
    }
    private fun setupImagePicker() {
        imagePickerLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                selectedImageUri = it
                binding.ivCampaignImagePreview.setImageURI(it)
            }
        }
        binding.btnSelectCampaignImage.setOnClickListener {
            imagePickerLauncher.launch("image/*")
        }
    }

    private fun setupButtonListener() {
        binding.btnSubmitCampaign.setOnClickListener {
            // Ambil data dari EditText dan kirim ke ViewModel
            viewModel.submitCampaign(
                title = binding.etCampaignTitle.text.toString(),
                description = binding.etCampaignDescription.text.toString(),
                targetAmount = binding.etTargetAmount.text.toString(),
                imageUri = selectedImageUri
            )
        }
    }

    private fun observeViewModel() {
        viewModel.creationResult.observe(this) { result ->
            result.onSuccess { campaign ->
                showSuccessDialog("Kampanye '${campaign.title}' berhasil diajukan dan menunggu verifikasi admin.")
            }
            result.onFailure { error ->
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_LONG).show()
            }
        }

        viewModel.isLoading.observe(this) { isLoading ->
            binding.btnSubmitCampaign.isEnabled = !isLoading
            binding.btnSubmitCampaign.text = if (isLoading) "Mengirim..." else "Ajukan Kampanye"
        }
        viewModel.isLoading.observe(this) { isLoading ->
            if (isLoading) {
                // Saat sedang loading/mengirim data:
                binding.btnSubmitCampaign.isEnabled = false // Nonaktifkan tombol
                binding.btnSubmitCampaign.text = "Mengirim..." // Ubah teksnya
            } else {
                // Saat proses selesai (baik sukses maupun gagal):
                binding.btnSubmitCampaign.isEnabled = true // Aktifkan kembali tombol
                binding.btnSubmitCampaign.text = "Ajukan Kampanye" // Kembalikan teksnya
            }
        }
    }

    private fun showSuccessDialog(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Pengajuan Berhasil")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                finish() // Tutup halaman setelah berhasil
            }
            .setCancelable(false)
            .show()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}