package com.example.frontend.data.repositories

import android.content.Context
import com.example.frontend.data.remote.RetrofitInstance
import com.example.frontend.data.remote.VerifyDisbursementRequest
import com.example.frontend.data.remote.VerifyDonationRequest
import com.example.frontend.data.remote.VerifyRequest

class AdminRepository(private val context: Context) {

    private val apiService = RetrofitInstance.create(context)

    suspend fun getAllCampaigns() = apiService.getCampaigns()

    suspend fun getDashboardStats() = apiService.getDashboardStats()

    suspend fun getPendingDonations() = apiService.getPendingDonations()

    suspend fun verifyDonation(donationId: String, isSuccess: Boolean) =
        apiService.verifyDonation(
            donationId = donationId,
            request = VerifyDonationRequest(status = if (isSuccess) "success" else "failed")
        )
    suspend fun getPendingDisbursements() = apiService.getPendingDisbursements()

    suspend fun verifyDisbursement(disbursementId: String, status: String) =
        apiService.verifyDisbursement(
            disbursementId = disbursementId,
            request = VerifyDisbursementRequest(status = status)
        )
    suspend fun verifyCampaign(campaignId: String, newStatus: String) =
        apiService.verifyCampaign(
            campaignId = campaignId,
            request = VerifyRequest(status = newStatus)
        )
}