package com.example.frontend.ui.Donatur.History

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.frontend.R
import com.example.frontend.databinding.ActivityDonationHistoryBinding

class DonationHistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDonationHistoryBinding
    private val viewModel: DonationHistoryViewModel by viewModels()
    private lateinit var adapter: DonationHistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDonationHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)


        setupToolbar()
        setupRecyclerView()
        observeViewModel()
    }
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbarHistory)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    private fun setupRecyclerView() {
        adapter = DonationHistoryAdapter(emptyList())
        binding.rvDonationHistory.adapter = adapter
        binding.rvDonationHistory.layoutManager = LinearLayoutManager(this)
    }

    private fun observeViewModel() {
        viewModel.history.observe(this) { history ->
            adapter.updateData(history)
        }
    }
}