package com.example.frontend.ui.fundraiser

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.frontend.R
import com.example.frontend.data.remote.DisbursementItem
import com.example.frontend.databinding.ItemDisbursementHistoryBinding
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class DisbursementHistoryAdapter(
    private var items: List<DisbursementItem> = emptyList()
) : RecyclerView.Adapter<DisbursementHistoryAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemDisbursementHistoryBinding) : RecyclerView.ViewHolder(binding.root)

    fun updateData(newItems: List<DisbursementItem>) {
        this.items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemDisbursementHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context

        holder.binding.tvCampaignTitleHistory.text = "Pencairan: ${item.campaign.title}"

        // Mengatur dan Memformat Jumlah Uang
        val localeID = Locale("in", "ID")
        val currencyFormat = NumberFormat.getCurrencyInstance(localeID).apply { maximumFractionDigits = 0 }
        holder.binding.tvAmountHistory.text = currencyFormat.format(item.amount)

        // Mengatur dan Memformat Tanggal
        holder.binding.tvDateHistory.text = "Diajukan pada: ${formatDate(item.requestedAt)}"

        // Mengatur Teks dan Warna Status Chip
        when (item.status.lowercase()) {
            "pending" -> {
                holder.binding.chipStatusHistory.text = "Pending"
                holder.binding.chipStatusHistory.setChipBackgroundColorResource(R.color.status_pending)
            }
            "approved", "processed" -> {
                holder.binding.chipStatusHistory.text = "Disetujui"
                holder.binding.chipStatusHistory.setChipBackgroundColorResource(R.color.brand_green)
            }
            "rejected" -> {
                holder.binding.chipStatusHistory.text = "Ditolak"
                holder.binding.chipStatusHistory.setChipBackgroundColorResource(R.color.brand_red)
            }
            else -> {
                holder.binding.chipStatusHistory.text = item.status.capitalize()
                holder.binding.chipStatusHistory.setChipBackgroundColorResource(android.R.color.darker_gray)
            }
        }
    }

    // Fungsi helper untuk mengubah format tanggal dari server
    private fun formatDate(isoString: String): String {
        return try {
            val serverFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val date = serverFormat.parse(isoString)

            val displayFormat = SimpleDateFormat("dd MMM yyyy", Locale("in", "ID"))
            displayFormat.format(date!!)
        } catch (e: Exception) {
            "Tanggal tidak valid"
        }
    }
}