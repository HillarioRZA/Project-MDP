package com.example.frontend.ui.Donatur.DonatePage

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.frontend.data.remote.DonationResponse
import com.example.frontend.data.repositories.DonationRepository
import kotlinx.coroutines.launch

class DonationViewModel(application: Application) : AndroidViewModel(application) {
    private val donationRepository = DonationRepository(application)

    // Hasil dari proses donasi
    private val _donationResult = MutableLiveData<Result<DonationResponse>>()
    val donationResult: LiveData<Result<DonationResponse>> = _donationResult

    fun submitDonation(
        campaignId: String,
        amount: String,
        isAnonymous: Boolean,
        imageUri: Uri?
    ) {
        // Validasi
        if (imageUri == null) {
            _donationResult.value = Result.failure(Exception("Bukti transaksi wajib diupload"))
            return
        }

        viewModelScope.launch {
            try {
                val response = donationRepository.createDonation(campaignId, amount, isAnonymous, imageUri)
                if (response.isSuccessful && response.body() != null) {
                    _donationResult.postValue(Result.success(response.body()!!))
                } else {
                    _donationResult.postValue(Result.failure(Exception("Gagal membuat donasi: ${response.errorBody()?.string()}")))
                    Log.e("DonationViewModel", "Error response: ${response.errorBody()?.string().toString()}")
                }
            } catch (e: Exception) {
                _donationResult.postValue(Result.failure(e))
            }
        }
    }
}