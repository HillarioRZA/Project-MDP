package com.example.frontend.ui.DetailCampaign

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.frontend.data.remote.CampaignItem
import com.example.frontend.data.remote.DonatorItem
import com.example.frontend.data.repositories.CampaignRepository
import kotlinx.coroutines.launch

class DetailCampaignViewModel(application: Application) : AndroidViewModel(application) {

    private val campaignRepository = CampaignRepository(application)

    private val _campaignDetail = MutableLiveData<CampaignItem>()
    val campaignDetail: LiveData<CampaignItem> = _campaignDetail

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    private val _donators = MutableLiveData<List<DonatorItem>>()
    val donators: LiveData<List<DonatorItem>> = _donators
    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    fun fetchCampaignData(campaignId: String) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                // Ambil data detail kampanye
                val detailResponse = campaignRepository.getCampaignById(campaignId)
                if (detailResponse.isSuccessful && detailResponse.body() != null) {
                    _campaignDetail.postValue(detailResponse.body())
                } else {
                    _error.postValue("Gagal memuat detail: ${detailResponse.message()}")
                }

                // Ambil data daftar donatur
                val donatorsResponse = campaignRepository.getDonationsByCampaignId(campaignId)
                if (donatorsResponse.isSuccessful && donatorsResponse.body() != null) {
                    _donators.postValue(donatorsResponse.body())
                } else {
                    _error.postValue("Gagal memuat daftar donatur")
                }

            } catch (e: Exception) {
                _error.postValue("Terjadi error: ${e.message}")
            } finally {
                _isLoading.postValue(false)
            }
        }
    }
}