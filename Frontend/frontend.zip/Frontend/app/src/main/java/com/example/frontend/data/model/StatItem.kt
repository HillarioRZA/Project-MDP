package com.example.frontend.data.model

data class StatItem(
    val value: String,
    val label: String
)